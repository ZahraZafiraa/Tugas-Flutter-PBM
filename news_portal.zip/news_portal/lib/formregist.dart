import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'home.dart';

class RegistPage extends StatefulWidget {
  @override
  _RegistPageState createState() => _RegistPageState();
}

class _RegistPageState extends State<RegistPage> {
  final TextEditingController userController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  final TextEditingController pass2Controller = TextEditingController();

  // Fungsi untuk menambahkan data pengguna
  Future<void> addDataUser(
    TextEditingController userController,
    TextEditingController passController,
    TextEditingController pass2Controller,
  ) async {
    // Validasi input pengguna
    if (userController.text.isNotEmpty &&
        passController.text.isNotEmpty &&
        pass2Controller.text.isNotEmpty &&
        passController.text == pass2Controller.text) {
      final Uri link = Uri.parse('https://e-commerce-store.glitch.me/signup');

      try {
        final response = await http.post(
          link,
          body: {
            "username": userController.text,
            "password": passController.text,
          },
        );

        if (response.statusCode == 200) {
          _showSuccessToast("Registrasi berhasil.");
          Navigator.pop(context);
        } else {
          _showErrorToast("Registrasi gagal. Coba lagi.");
        }
      } catch (e) {
        _showErrorToast(
          "Terjadi kesalahan. Pastikan Anda terhubung ke internet.",
        );
      }
    } else {
      // Kosongkan form jika validasi gagal
      userController.clear();
      passController.clear();
      pass2Controller.clear();
      _showErrorToast("Pastikan semua kolom terisi dengan benar.");
    }
  }

  // Menampilkan pesan toast jika ada error
  void _showErrorToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  // Menampilkan pesan toast jika sukses
  void _showSuccessToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Container(
            margin: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Registrasi',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: userController,
                  decoration: const InputDecoration(hintText: "Username"),
                ),
                TextField(
                  controller: passController,
                  decoration: const InputDecoration(hintText: "Password"),
                  obscureText: true,
                ),
                TextField(
                  controller: pass2Controller,
                  decoration: const InputDecoration(hintText: "Konfirmasi Password"),
                  obscureText: true,
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16.0,
                          vertical: 12.0,
                        ),
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text(
                        'Back',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 20),
                    TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16.0,
                          vertical: 12.0,
                        ),
                      ),
                      onPressed: () {
                        addDataUser(userController, passController, pass2Controller);
                      },
                      child: const Text(
                        'Sign Up',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
