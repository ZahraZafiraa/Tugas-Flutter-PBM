import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class KategoriPage extends StatefulWidget {
  @override
  _KategoriPageState createState() => _KategoriPageState();
}

class _KategoriPageState extends State<KategoriPage> {
  late FToast fToast;

  @override
  void initState() {
    super.initState();
    fToast = FToast();
    fToast.init(context);
  }

  // Fungsi untuk menampilkan toast saat kategori dipilih
  Widget iconTag({required Icon icon, required String tag}) {
    return IconButton(
      icon: icon,
      onPressed: () {
        fToast.showToast(
          toastDuration: const Duration(milliseconds: 2000),
          child: Container(
            margin: const EdgeInsets.only(bottom: 20),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25.0),
              color: Colors.grey,
            ),
            child: Text(
              'Anda memilih kategori $tag',
              style: const TextStyle(color: Colors.white),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kategori Page')),
      body: Container(
        margin: const EdgeInsets.all(15),
        child: Column(
          children: [
            // Kategori General
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue, width: 3),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('General'),
                  Container(height: 1.5, color: Colors.grey),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      iconTag(icon: const Icon(Icons.attach_money), tag: 'General'),
                      iconTag(icon: const Icon(Icons.card_travel), tag: 'General'),
                      iconTag(icon: const Icon(Icons.local_hospital), tag: 'General'),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 15),

            // Kategori Entertainment
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue, width: 3),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Entertainment'),
                  Container(height: 1.5, color: Colors.grey),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      iconTag(icon: const Icon(Icons.fastfood), tag: 'Entertainment'),
                      iconTag(icon: const Icon(Icons.hotel), tag: 'Entertainment'),
                      iconTag(icon: const Icon(Icons.local_grocery_store), tag: 'Entertainment'),
                      iconTag(icon: const Icon(Icons.local_movies), tag: 'Entertainment'),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 15),

            // Kategori Transportasi
            Container(
              padding: const EdgeInsets.fromLTRB(5, 5, 5, 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue, width: 3),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Transportasi'),
                  Container(height: 1.5, color: Colors.grey),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      iconTag(icon: const Icon(Icons.directions_bike), tag: 'Transportasi'),
                      iconTag(icon: const Icon(Icons.motorcycle), tag: 'Transportasi'),
                      iconTag(icon: const Icon(Icons.directions_car), tag: 'Transportasi'),
                      iconTag(icon: const Icon(Icons.local_shipping), tag: 'Transportasi'),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      iconTag(icon: const Icon(Icons.directions_bus), tag: 'Transportasi'),
                      iconTag(icon: const Icon(Icons.directions_boat), tag: 'Transportasi'),
                      iconTag(icon: const Icon(Icons.train), tag: 'Transportasi'),
                      iconTag(icon: const Icon(Icons.airplanemode_active), tag: 'Transportasi'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
