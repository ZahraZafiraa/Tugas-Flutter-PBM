package com.example.news_portal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
